package com.sample.model;

public enum PetType {
	   DOG,CAT,PARROT
}
